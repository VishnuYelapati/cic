package com.edu.myapp.data.model

data class User(
    val email: String = "",
    val password: String = ""
)